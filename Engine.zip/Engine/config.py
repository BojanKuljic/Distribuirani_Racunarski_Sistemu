# config.py

MAIL_SERVER = 'smtp.office365.com' 
MAIL_PORT = 587
MAIL_USE_TLS = True
MAIL_USE_SSL = False
MAIL_USERNAME = 'DrsTeam2@outlook.com'
MAIL_PASSWORD = 'ThereIsN0Password'
MAIL_DEFAULT_SENDER = 'DrsTeam2@outlook.com'
SESSION_TYPE = 'filesystem'